package org.ww.wigglew.aex.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.ww.wigglew.aex.entity.QuestionExamEntity;


public interface QuestionExamRepository extends JpaRepository<QuestionExamEntity, Long> {
}

