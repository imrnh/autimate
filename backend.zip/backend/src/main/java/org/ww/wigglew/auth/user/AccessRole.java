package org.ww.wigglew.auth.user;

public enum AccessRole {
    USER,
    ADMIN
}
